import { db, schema, json, currentKey } from '../lib/core.js';
export const config = { runtime: 'edge' };
const map = (rows, k, v) => Object.fromEntries(rows.map(r => [r[k], r[v]]));

export default async function handler(req) {
  await schema();
  const sql = db(), me = await currentKey(req);
  const [videos, likes, cm, fol, acc, mine, following, self] = await Promise.all([
    sql`SELECT id, owner, caption, tags, url, download_url, ext, created FROM videos ORDER BY created DESC LIMIT 100`,
    sql`SELECT video_id, count(*)::int AS n FROM likes GROUP BY video_id`,
    sql`SELECT video_id, count(*)::int AS n FROM comments GROUP BY video_id`,
    sql`SELECT followee, count(*)::int AS n FROM follows GROUP BY followee`,
    sql`SELECT key, name, verified FROM users`,
    me ? sql`SELECT video_id FROM likes WHERE user_key = ${me}` : [],
    me ? sql`SELECT followee FROM follows WHERE follower = ${me}` : [],
    me ? sql`SELECT key, name, verified, username_set FROM users WHERE key = ${me}` : [],
  ]);
  return json({
    me: self[0] ? { key: self[0].key, name: self[0].name, verified: self[0].verified, usernameSet: self[0].username_set } : null,
    videos: videos.map(v => ({ id: v.id, aid: v.id, u: v.owner, cap: v.caption, tags: v.tags, url: v.url, downloadUrl: v.download_url, ext: v.ext, at: new Date(v.created).getTime() })),
    likes: map(likes, 'video_id', 'n'),
    cm: map(cm, 'video_id', 'n'),
    fol: map(fol, 'followee', 'n'),
    acc: Object.fromEntries(acc.map(a => [a.key, { name: a.name, verified: a.verified }])),
    mine: mine.map(r => r.video_id),
    following: following.map(r => r.followee),
  });
}
