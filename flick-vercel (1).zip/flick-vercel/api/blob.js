import { handleUpload } from '@vercel/blob/client';
import { currentKey, json } from '../lib/core.js';
export const config = { runtime: 'edge' };

export default async function handler(request) {
  if (request.method !== 'POST') return json({ error: 'Use POST.' }, 405);
  try {
    const body = await request.json();
    const result = await handleUpload({
      body,
      request,
      onBeforeGenerateToken: async pathname => {
        if (!(await currentKey(request))) throw new Error('Log in to Flick first.');
        if (!/^v[a-z0-9]{4,20}\.(mp4|webm|mov)$/.test(pathname)) throw new Error('Bad file name.');
        return { allowedContentTypes: ['video/mp4', 'video/webm', 'video/quicktime'], maximumSizeInBytes: 20 * 1024 * 1024, addRandomSuffix: false };
      },
      onUploadCompleted: async () => {},
    });
    return json(result);
  } catch (e) {
    return json({ error: e.message || 'Upload not allowed.' }, 400);
  }
}
