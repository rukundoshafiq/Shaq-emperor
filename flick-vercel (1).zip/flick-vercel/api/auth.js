import { db, schema, json, hashPw, makeCookie, currentKey, hex, newKey } from '../lib/core.js';
export const config = { runtime: 'edge' };
const LOGOUT = 'flick=; Path=/; Max-Age=0; HttpOnly; Secure; SameSite=Lax';
const RESERVED = ['founder', 'flick', 'admin', 'support', 'about'];
const EMAIL = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;
const USERNAME = /^[a-z0-9_.]{3,20}$/;
const pick = u => ({ key: u.key, name: u.name, verified: u.verified, usernameSet: u.username_set });

export default async function handler(req) {
  if (req.method !== 'POST') return json({ error: 'Use POST.' }, 405);
  const b = await req.json().catch(() => ({}));
  if (b.a === 'logout') return json({ ok: true }, 200, { 'set-cookie': LOGOUT });
  await schema();
  const sql = db(), pw = String(b.password || '');
  if (b.a === 'signup') {
    const email = String(b.email || '').trim().toLowerCase();
    if (!EMAIL.test(email)) return json({ error: 'Enter a valid email address.' }, 400);
    if (pw.length < 6 || pw.length > 64) return json({ error: 'Password needs 6–64 characters.' }, 400);
    const salt = hex(crypto.getRandomValues(new Uint8Array(16)));
    const hash = await hashPw(pw, salt);
    for (let i = 0; i < 5; i++) {
      const key = newKey(), username = 'user' + String(Math.floor(Math.random() * 1e8)).padStart(8, '0');
      try {
        await sql`INSERT INTO users (key, name, username, username_set, email, salt, hash) VALUES (${key}, ${username}, ${username}, false, ${email}, ${salt}, ${hash})`;
        return json({ user: { key, name: username, verified: false, usernameSet: false } }, 200, { 'set-cookie': await makeCookie(key) });
      } catch (e) {
        const dup = await sql`SELECT key FROM users WHERE email = ${email}`;
        if (dup.length) return json({ error: 'That email already has an account. Log in instead.' }, 409);
      }
    }
    return json({ error: 'Could not create the account. Try again.' }, 500);
  }
  if (b.a === 'login') {
    const id = String(b.identifier || '').trim().toLowerCase();
    if (!id || pw.length < 6) return json({ error: 'Wrong email/username or password.' }, 401);
    const [u] = await sql`SELECT key, name, verified, username_set, salt, hash FROM users WHERE email = ${id} OR username = ${id} LIMIT 1`;
    if (!u || (await hashPw(pw, u.salt)) !== u.hash) return json({ error: 'Wrong email/username or password.' }, 401);
    return json({ user: pick(u) }, 200, { 'set-cookie': await makeCookie(u.key) });
  }
  if (b.a === 'username') {
    const me = await currentKey(req);
    if (!me) return json({ error: 'Log in first.' }, 401);
    const un = String(b.username || '').trim().toLowerCase();
    if (!USERNAME.test(un)) return json({ error: 'Use 3–20 letters, numbers, _ or .' }, 400);
    if (RESERVED.includes(un)) return json({ error: 'That username is reserved.' }, 400);
    try {
      const [u] = await sql`UPDATE users SET username = ${un}, name = ${un}, username_set = true WHERE key = ${me} RETURNING key, name, verified, username_set`;
      return json({ user: pick(u) });
    } catch (e) {
      return json({ error: 'That username is taken.' }, 409);
    }
  }
  return json({ error: 'Unknown action.' }, 400);
}
