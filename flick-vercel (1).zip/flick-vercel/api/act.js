import { db, schema, json, currentKey } from '../lib/core.js';
export const config = { runtime: 'edge' };
const VERIFY_AT = 10000;
const STORAGE = /^https:\/\/[^/]+\.vercel-storage\.com\//;
const shape = x => ({ id: x.id, aid: x.id, u: x.owner, cap: x.caption, tags: x.tags, url: x.url, downloadUrl: x.download_url, ext: x.ext, at: new Date(x.created).getTime() });

export default async function handler(req) {
  await schema();
  const sql = db();
  if (req.method === 'GET') {
    const sp = new URL(req.url).searchParams;
    if (sp.get('user')) {
      const user = sp.get('user').toLowerCase();
      const rows = await sql`SELECT id, owner, caption, tags, url, download_url, ext, created FROM videos WHERE owner = ${user} ORDER BY created DESC LIMIT 300`;
      return json({ videos: rows.map(shape) });
    }
    if (sp.get('friends') || sp.get('activities')) {
      const me = await currentKey(req);
      if (!me) return json({ error: 'Log in first.' }, 401);
      if (sp.get('friends')) {
        const rows = await sql`SELECT f1.followee AS key FROM follows f1 JOIN follows f2 ON f2.follower = f1.followee AND f2.followee = f1.follower WHERE f1.follower = ${me}`;
        return json({ keys: rows.map(r => r.key) });
      }
      const rows = await sql`
        SELECT 'like' AS type, l.user_key AS who, v.caption AS cap, NULL::text AS body, l.created AS ts
          FROM likes l JOIN videos v ON v.id = l.video_id WHERE v.owner = ${me} AND l.user_key <> ${me}
        UNION ALL
        SELECT 'comment', c.user_key, v.caption, c.body, c.created
          FROM comments c JOIN videos v ON v.id = c.video_id WHERE v.owner = ${me} AND c.user_key <> ${me}
        UNION ALL
        SELECT 'follow', f.follower, NULL::text, NULL::text, f.created FROM follows f WHERE f.followee = ${me}
        ORDER BY ts DESC LIMIT 60`;
      return json({ items: rows.map(r => ({ type: r.type, who: r.who, cap: r.cap, body: r.body, at: new Date(r.ts).getTime() })) });
    }
    const v = sp.get('comments') || '';
    if (!v) return json({ error: 'Missing video.' }, 400);
    const rows = await sql`SELECT name, body, created FROM comments WHERE video_id = ${v} ORDER BY created ASC LIMIT 200`;
    return json({ comments: rows.map(r => ({ name: r.name, t: r.body, at: new Date(r.created).getTime() })) });
  }
  if (req.method !== 'POST') return json({ error: 'Use GET or POST.' }, 405);
  const me = await currentKey(req);
  if (!me) return json({ error: 'Log in to Flick first.' }, 401);
  const b = await req.json().catch(() => ({}));
  const vid = String(b.videoId || b.id || '').slice(0, 40);
  if (b.a === 'like') {
    if (!vid) return json({ error: 'Missing video.' }, 400);
    if (b.on) await sql`INSERT INTO likes (video_id, user_key) VALUES (${vid}, ${me}) ON CONFLICT DO NOTHING`;
    else await sql`DELETE FROM likes WHERE video_id = ${vid} AND user_key = ${me}`;
    return json({ ok: true });
  }
  if (b.a === 'follow') {
    const u = String(b.username || '').toLowerCase();
    if (!/^[a-z0-9_.]{1,20}$/.test(u) || u === me) return json({ error: "Can't follow that account." }, 400);
    if (b.on) await sql`INSERT INTO follows (follower, followee) VALUES (${me}, ${u}) ON CONFLICT DO NOTHING`;
    else await sql`DELETE FROM follows WHERE follower = ${me} AND followee = ${u}`;
    const [{ n }] = await sql`SELECT count(*)::int AS n FROM follows WHERE followee = ${u}`;
    const verified = n >= VERIFY_AT;
    if (verified) await sql`UPDATE users SET verified = true WHERE key = ${u}`;
    return json({ followers: n, verified });
  }
  if (b.a === 'comment') {
    const text = String(b.text || '').trim().slice(0, 140);
    if (!vid || !text) return json({ error: 'Write something first.' }, 400);
    const [u] = await sql`SELECT name FROM users WHERE key = ${me}`;
    await sql`INSERT INTO comments (video_id, user_key, name, body) VALUES (${vid}, ${me}, ${u ? u.name : me}, ${text})`;
    return json({ ok: true });
  }
  if (b.a === 'video') {
    const id = String(b.id || ''), ext = String(b.ext || '').toLowerCase();
    const url = String(b.url || ''), dl = String(b.downloadUrl || url);
    const caption = String(b.caption || '').trim().slice(0, 150) || 'Untitled';
    const tags = (caption.match(/#[\p{L}\p{N}_]+/gu) || []).join(' ');
    if (!/^v[a-z0-9]{4,20}$/.test(id) || !['mp4', 'webm', 'mov'].includes(ext)) return json({ error: 'Bad video details.' }, 400);
    if (!STORAGE.test(url) || !STORAGE.test(dl)) return json({ error: "Video didn't come from storage." }, 400);
    await sql`INSERT INTO videos (id, owner, caption, tags, url, download_url, ext) VALUES (${id}, ${me}, ${caption}, ${tags}, ${url}, ${dl}, ${ext})`;
    return json({ ok: true });
  }
  return json({ error: 'Unknown action.' }, 400);
}
